def saludar():
    print("te saludos desde saludos.saludar()")


def prueba():
    print("Mensaje de prueba")


class Saludo:
    def __init__(self):
        print("Hola, te saludo desde Saludo.__init__")

# print(__name__)


if __name__ == '__main__':
    saludar()

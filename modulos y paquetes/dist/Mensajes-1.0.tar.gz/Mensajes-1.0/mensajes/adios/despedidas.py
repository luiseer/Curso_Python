def despedir():
    print("Adios, me despido desde despedidas.despedir()")


class Despedida:
    def __init__(self):
        print("Adios, me despido desde Despedida.__init__")


if __name__ == '__main__':
    despedir()
    Despedida()
